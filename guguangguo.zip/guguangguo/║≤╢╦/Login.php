<?php
// 链接上数据库
include_once 'conn.php';

// 接收前端传过来的用户名和密码
$username = $_GET['username'];
$password = $_GET['password'];

// 定义一个空数组、用于存放返回的数据
$a = array();

// 用户名、密码不能为空 0:false   非0:true
if(!strlen($username) || !strlen($password)){
    $a['error'] = 1;
    $a['msg'] = '后端：用户名、密码，反正你有一个没填';
    echo json_encode($a);
    exit;  // 终止程序往下运行
}

// 密码不能低于6位、或者密码不能大于18位
if(strlen($password) < 6 || strlen($password) > 18){
    $a['error'] = 1;
    $a['msg'] = '后端：密码不能低于6位、或者密码不能大于18位';
    echo json_encode($a);
    exit;  // 终止程序往下运行
}

// 先把密码加密为密文
$password_md5 = md5($password);
// 去数据库查询，有没有这样一条数据，用户名和密码都等于前端输入的用户名和密码
$sql = "SELECT * FROM `users` WHERE `username` = '$username' and `password` = '$password_md5'";
// 执行上面的sql查询语句，得到一个结果集
$result = mysqli_query($conn,$sql);
// 数一下结果集里有多少条数据
$num = mysqli_num_rows($result);
// 如果查出来有1条以上，就为true（登录成功），否者为false（登录失败）
if($num){
    $a['error'] = 0;
    $a['msg'] = '登录成功';
    echo json_encode($a);
    exit;
}else{
    $a['error'] = 1;
    $a['msg'] = '用户名或密码错误';
    echo json_encode($a);
    exit;
}
?>