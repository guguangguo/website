<template>
	<view>
		<div class="buyform">
			<!-- @blur="bindTextAreaBlur" -->
			<textarea auto-height="" placeholder="输入留言内容" v-model="content" maxlength="50"></textarea>
			<p class="number">字数提示：{{content.length}}/50</p>
		</div>
		<button class="buttons" type="submit" @click="commit()">提交</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				content:''   // 用户输入的内容
			}
		},
		methods: {
			// 发布按钮
			commit(){
				// 前端空校验
				if(this.content == ''){
					alert('请输入内容')
					return
				}
				// 从缓存里去取用户名
				const username = uni.getStorageSync('username')
				// 发请求到后端
				uni.request({
					url:'http://localhost:7777/Commit.php',
					method:'GET',
					data:{
						content: this.content,
						username: username
					},
					// 发送请求成功
					success: (res) => {
						console.log(res)
						// 如果发布成功
						if (res.data.error == 0) {
							uni.showToast({
								title:res.data.msg
							})
							// 跳转到广场页面
							uni.switchTab({
								url:'/pages/index/index'
							})
							this.content = ''
						}else{
							uni.showToast({
								title:res.data.msg,
								icon:'error'
							})
						}
					}
				})
			}
		},
		// 当页面自动显示的时候,自动执行一次
		onShow: () => {
			// 从缓存里去取用户名
			const username = uni.getStorageSync('username')
			console.log(username);
			// 如果没有用户名
			if (!username){   // ''为false，否则就是true
				// 弹一个登录的对话框
				uni.showModal({
					title: '提示',
					content: '请先登录',
					success: function (res) {
						// 如果点击确定的话
						if (res.confirm) {
							// 跳转到登录页面
							uni.navigateTo({
								url:'/pages/login/login'
							})
						// 如果用户点击了取消
						} else if (res.cancel) {
							// 跳转到登录页面
							uni.navigateTo({
								url:'/pages/login/login'
							})
						}
					}
				});
			}
		}
	}
</script>

<style>
	view{
		background-image: linear-gradient(to bottom,#9f0000,#000000);
		transition: background-image 2s ease-in-out;
		height: 85.9vh;
	}
	textarea{
		color: aliceblue;
		/* border: 1PX solid white; */
	}
	button {
	    appearance: auto;
	    -webkit-writing-mode: horizontal-tb !important;
	    text-rendering: auto;
	    color: -internal-light-dark(black, white);
	    letter-spacing: normal;
	    word-spacing: normal;
	    text-transform: none;
	    text-indent: 0px;
	    text-shadow: none;
	    display: inline-block;
	    text-align: center;
	    align-items: flex-start;
	    cursor: default;
	    background-color: -internal-light-dark(rgb(239, 239, 239), rgb(59, 59, 59));
	    box-sizing: border-box;
	    margin: 0em;
	    font: 400 13.3333px Arial;
	    padding: 1px 6px;
	    border-width: 2px;
	    border-style: outset;
	    border-color: -internal-light-dark(rgb(118, 118, 118), rgb(133, 133, 133));
	    border-image: initial;
	}
	.buyform {
		display: flex;
		position: absolute;
		left: 50%;
		transform: translate(-50%);
		padding: 32px;
		background: url(../../static/bottom_info_text.png);
		background-repeat: no-repeat;
		background-size: contain;
		width: 45vh;
		height: 50vh;
		top: 2vh;
	}
	.buttons {
		text-align: center;
		padding: 8px;
		width: 128px;
		text-decoration: none;
		color: black;
		background: url(../../static/buttonbg.png);
		background-repeat: no-repeat;
		transition: all 0.2s ease-in-out;
		top: 40vh;
		left: 18vh;
	}
	.buttons:active {
		transform: scale(1.1);
		transition: all 0.2s ease-in-out;
		opacity: 0.5;
	}
	.buttons:active {
		transition: opacity 0.1s ease-in-out;
		opacity: 0.5;
	}
	.number{
		color: aliceblue;
		position: absolute;
		top: 30vh;
	}
</style>
