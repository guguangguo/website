<?php
// 连接数据库
include_once 'conn.php';

// 接收前端传过来的新密码和用户名(并且用trim()函数去掉空格)
$new_password = trim($_GET['new_password']);
$username = trim($_GET['username']);

// 定义一个空数组，这个数组是用来存放返回的数据
$a = array();

// 参数的空校验
if(strlen($new_password) == 0){
    $a['msg'] = '新密码没填';
    $a['error'] = 1;
    echo json_encode($a);
    exit; // 终止程序往下运行
}
if(strlen($username) == 0){
    $a['msg'] = '请先登录';
    $a['error'] = 1;
    echo json_encode($a);
    exit; // 终止程序往下运行
}

// 把密码加密成密文（md5）
$new_password_md5 = md5($new_password);
// 准备好sql语句
$sql = "UPDATE `users` SET `password`='$new_password_md5' WHERE `username` = '$username'";
// 执行sql语句，会返回一个布尔值，如果执行成功，会返回True，否则返回False
$result = mysqli_query($conn,$sql);
// 如果执行成功
if($result){
    $a['msg'] = '修改成功';
    $a['error'] = 0;
    echo json_encode($a);
    exit; // 终止程序往下运行
}else{
    $a['msg'] = '修改失败';
    $a['error'] = 1;
    echo json_encode($a);
    exit; // 终止程序往下运行
}
?>