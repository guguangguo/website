<?php
// 连接数据库服务器(用户名、密码、数据库名)
$conn = mysqli_connect("localhost","admin","123456","web");
if(!$conn){
    die('连接数据库失败');
}

// 设置字符集
mysqli_query($conn,"set names utf8");