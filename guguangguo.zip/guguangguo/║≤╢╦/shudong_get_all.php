<?php 
// 连接数据库
include_once 'conn.php';

// 构建sql语句(通过id排序，并且是倒序)
$sql = "SELECT * FROM `shudong` WHERE 1 ORDER BY `id` DESC;";

// 执行sql语句
// 增删改——返回值是一个布尔值，只有查询是返回一个结果集
$result = mysqli_query($conn,$sql);
// 取出一条数据中的所有字段，作为一个数组
// $info = mysqli_fetch_array($result);

// 定义一个空数组、用来存放将要返回的所有的数据
$a = array();
// 通过循环获取所有的数据
while( $info = mysqli_fetch_array($result) ){
    $a[] = $info;
}

echo json_encode($a);

?>