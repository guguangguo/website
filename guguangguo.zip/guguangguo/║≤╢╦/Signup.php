<?php
// 引入连接数据库的文件，如果成功连接的话，会得到一个$conn
include_once 'conn.php';

// 接受前端传过来的参数
// trim(str)就是去掉str的两头的空格
$username =trim($_GET['username']);
$password =trim($_GET['password']);
$cpassword =trim($_GET['cpassword']);

$a = array(); // 定义了一个空的数组，用来存放返回的数据

// 用户名、密码、确认密码不能为空 0:false   非0:true
if(!strlen($username) || !strlen($password) || !strlen($cpassword)){
    $a['error'] = 1;
    $a['msg'] = '后端：用户名、密码、确认密码，反正你有一个没填';
    echo json_encode($a);
    exit;  // 终止程序往下运行
}

// 密码不能低于6位、或者密码不能大于18位
if(strlen($password) < 6 || strlen($password) > 18){
    $a['error'] = 1;
    $a['msg'] = '后端：密码不能低于6位、或者密码不能大于18位';
    echo json_encode($a);
    exit;  // 终止程序往下运行
}

// 两次输入的密码不能不一样
if($password <> $cpassword){
    $a['error'] = 1;
    $a['msg'] = '后端：两次输入的密码不一样';
    echo json_encode($a);
    exit;
}

// 校验是否已存在同名的用户名
$sql = "SELECT * FROM `users` WHERE `username` = '$username'";
// 查———— 返回了一个结果集，增删改——返回了一个布尔值  
$result = mysqli_query($conn,$sql);
// 计算查询回来的结果多少条
$num = mysqli_num_rows($result);
if($num){
    $a['error'] = 1;
    $a['msg'] = '后端：该用户名已经注册，请换一个用户名';
    echo json_encode($a);
    exit;
}

// 将前端传过来的密码通过md5加密
$password_md5 = md5($password);

// 插入一条数据
$sql = "INSERT INTO `users`(`username`, `password`) VALUES ('$username','$password_md5')";
// 执行sql语句,返回一个布尔值，如果执行成功就返回ture,如果失败的话就返回false
$result = mysqli_query($conn,$sql);
if($result){
    $a['error'] = 0;
    $a['msg'] = '后端：注册成功';
}else{
    $a['error'] = 1;
    $a['msg'] = '后端：注册失败';
}

echo json_encode($a);
?>