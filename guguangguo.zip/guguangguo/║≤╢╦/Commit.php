<?php
// 连接数据库
include_once 'conn.php';

// 定义一个数组a,用于存放返回的数据
$a = array();

// 接收前端发过来的内容
$content = $_GET['content'];
$username = $_GET['username'];

// 插入一条数据
$sql = "INSERT INTO `shudong`(`username`, `content`) VALUES ('$username','$content')";
// 执行sql语句 (返回一个结果，如果执行成功，返回true，否则返回false)
$result = mysqli_query($conn,$sql);
if($result){
    $a['error'] = 0;
    $a['msg'] = '执行成功';
}else{
    $a['error'] = 1;
    $a['msg'] = '执行失败';
}

echo json_encode($a);
?>