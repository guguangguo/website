<template>
	<view class="bg_siup">
		<img src="/static/login.gif" alt="" class="image_box">
		<br /><text class="text_sign">hi~请登录</text>
		<br /><table class="input_box">
			<tr>
				<td>用户名：</td>
				<td><input type="text" v-model="username"></td>
			</tr>
			<tr>
				<td>密码：</td>
				<td><input type="text" v-model="password"></td>
			</tr>
		</table>
		<button @click="login()">登录</button>
		<navigator url="/pages/signup/signup">没有账号,请注册</navigator>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				username:'',
				password:''
			}
		},
		methods: {
			// 登陆按钮
			login(){
				// 输入框的空校验
				if(!this.username || !this.password){
					uni.showToast({
						title:'前端：用户名、密码，反正有一个没填',
						duration:3000,
						icon:'error'
					})
					return false
				}
				// 密码的长度不能小于6位
				if(this.password.length < 6 || this.password.length > 18){
					uni.showToast({
						title:'前端：密码不能小于6位、或者不能大于18位',
						duration:3000,
						icon:'error'
					})
					return false
				}
				// 发送登录请求
				uni.request({
					url:'http://localhost:7777/Login.php',
					method:'GET',
					data:{
						username:this.username,
						password:this.password
					},
					// 如果请求成功
					success: (res) => {
						console.log(res)
						// 用户登录成功
						if(res.data.error == 0){
							// 弹框提示用户
							uni.showToast({
								title:res.data.msg,
								icon:'success'
							})
							// 登录成功之后,将用户名保存在缓存里
							uni.setStorageSync('username',this.username)
							// const username = uni.getStorageSync('username')
							// console.log(username)
							// 如果登陆成功的话，跳转到个人中心页面
							uni.switchTab({
								url: '/pages/mine/mine'
							});
						}else{
							uni.showToast({
								title:res.data.msg,
								icon:'error'
							})
						}
					}
				})
			}
		}
	}
</script>

<style>
.bg_siup{
	width: 57vh;
	height: 93.4vh;
}
.image_box{
	width: 15vh;
	height: 15vh;
	margin: 13vh 0 0 20vh;
	border-radius: 15px;
}
.text_sign{
	margin: 5px 0 0 19vh;
	font-size: 25px;
	font-family: "Brush Script Std";
}
.input_box{
	margin: 3vh 0 0 2vh;
	font-size: 25px;
	font-family: "华文彩云";
}
tr td{
	color: hotpink;
}
input{
	border: 1px solid palevioletred;
	border-radius: 5px;
	font-size: 20px;
	padding-left: 4px;
}
button{
	width: 15vh;
	height: 45px;
	margin-left: 21vh;
	margin-top: 20px;
	font-family: "楷体";
	color: white;
	background-color: darkseagreen;
}
button:active{
	transform: scale(0.9);
}
.bg_siup navigator{
	text-align: center;
	margin-top: 3vh;
	font-family: "华文彩云";
	color: orangered;
}
</style>
