<template>
	<view class="bg_siup">
		<img src="/static/login.gif" alt="" class="image_box">
		<br /><text class="text_sign">hi~请注册</text>
		<br /><table class="input_box">
			<tr>
				<td>用户名：</td>
				<td><input type="text" v-model="username"></td>
			</tr>
			<tr>
				<td>密码：</td>
				<td><input type="text" v-model="password"></td>
			</tr>
			<tr>
				<td>确认密码：</td>
				<td><input type="text" v-model="cpassword"></td>
			</tr>
		</table>
		<button @click="zhuce()">注册</button>
		<navigator url="/pages/login/login">已有账号,请登录</navigator>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				username:'',
				password:'',
				cpassword:''
			}
		},
		methods: {
			// 注册按钮
			zhuce(){
				// 输入框的空校验
				if(!this.username || !this.password || !this.cpassword){
					uni.showToast({
						title:'前端：用户名、密码、确认密码、中有一个没填',
						duration:3000,
						icon:'error'
					})
					return false
				}
				// 密码的长度不能小于6位
				if(this.password.length < 6 || this.password.length > 18){
					uni.showToast({
						title:'前端：密码不能小于6位、或者不能大于18位',
						duration:3000,
						icon:'error'
					})
					return false
				}
				// 密码和确认密码不能不一样
				if(this.password != this.cpassword){
					uni.showToast({
						title:'前端：密码和确认密码不能不一样',
						duration:3000,
						icon:'error'
					})
					return false
				}
				// 发送请求到后端
				uni.request({
					url:'http://localhost:7777/Signup.php',
					data:{
						username:this.username,
						password:this.password,
						cpassword:this.cpassword
					},
					// 成功发送请求
					success: (res) => {
						console.log(res)
						// 如果注册失败
						if(res.data.error == 1){
							uni.showToast({
								title:res.data.msg,
								duration:3000,
								icon:'error'
							})
						// 否则就成功了
						}else{
							uni.showToast({
								title:res.data.msg,
								duration:3000,
								icon:'success'
							})
							uni.redirectTo({
								url:'/pages/login/login'
							})
						}
					}
				})
			}
		}
	}
</script>

<style>
.bg_siup{
	width: 57vh;
	height: 93.4vh;
	/* background-image: linear-gradient(-60deg,#faceff,#bcf1ff); */
}
.image_box{
	width: 15vh;
	height: 15vh;
	margin: 13vh 0 0 20vh;
	border-radius: 15px;
}
.text_sign{
	margin: 5px 0 0 19vh;
	font-size: 25px;
	font-family: "Brush Script Std";
}
.input_box{
	margin: 3vh 0 0 0vh;
	font-size: 25px;
	font-family: "华文彩云";
	padding-left: 2px;
}
tr td{
	color: hotpink;
}
input{
	border: 1px solid palevioletred;
	border-radius: 5px;
	font-size: 20px;
	padding-left: 4px;
}
button{
	border: 2px solid skyblue;
	width: 15vh;
	margin-left: 21vh;
	margin-top: 20px;
	font-family: "楷体";
	color: darkseagreen;
}
button:active{
	transform: scale(0.9);
}
.bg_siup navigator{
	text-align: center;
	margin-top: 3vh;
	font-family: "华文彩云";
	color: orangered;
}
</style>