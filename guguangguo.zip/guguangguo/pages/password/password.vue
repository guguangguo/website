<template>
	<view>
		<h4 class="top_title">修改密码</h4>
			<img src="/static/keli.jpg" alt="" class="image_box">
			<br /><text class="text_sign">hi~请修改</text>
			<br /><table class="input_box">
				<tr>
					<td>密码：</td>
					<td><input type="text" v-model="password"></td>
				</tr>
			</table>
			<button @click="zhuce()">修改</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				new_password:""
			}
		},
		methods: {
			// 修改密码
			mod_password(){
				// 新密码是从输入框获得的
				console.log(this.new_password)
				// 用户名是从缓存里面取的
				const username = uni.getStorageSync('username')
				// 参数空校验
				if(this.new_password.length == 0){
					uni.showToast({
						title:'请输入密码',
						icon:'error'
					})
					return
				}
				if(username.length == 0){
					uni.showToast({
						title:'请先登录',
						icon:'error'
					})
					return
				}
				// 发送请求给后端
				uni.request({
					url:'http://localhost:7777/mod_password.php',
					method:'GET',
					data:{
						new_password:this.new_password,
						username:username
					},
					success: (res) => {
						console.log(res)
						// 如果执行成功
						if (res.data.error == 0) {
							uni.showToast({
								title:res.data.msg,
								icon:'success'
							})
						// 否则就是失败了
						}else{
							uni.showToast({
								title:res.data.msg,
								icon:'error'
							})
						}
					}
				})
			}
		}
	}
</script>

<style>
	.top_title{
		width: 100%;
		height: 5vh;
		background-color: deepskyblue;
		text-align:center;
		padding-top: 10px;
		color: aliceblue;
	}
	.image_box{
		width: 15vh;
		height: 15vh;
		margin: 13vh 0 0 20vh;
		border-radius: 15px;
	}
	.text_sign{
		margin: 5px 0 0 19vh;
		font-size: 25px;
		font-family: "Brush Script Std";
	}
	.input_box{
		margin: 3vh 0 0 5vh;
		font-size: 25px;
		font-family: "微软雅黑";
	}
	tr td{
		color: blue;
	}
	input{
		border: 1px solid blue;
		border-radius: 5px;
		font-size: 20px;
		padding-left: 4px;
	}
	button{
		width: 15vh;
		height: 45px;
		margin-left: 21vh;
		margin-top: 20px;
		font-family: "楷体";
		color: white;
		background-color: darkseagreen;
	}
	button:active{
		transform: scale(0.9);
	}
</style>
