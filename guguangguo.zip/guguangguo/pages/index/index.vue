<template>
	<view>
		<table v-for="i in shudong_list">
			<tr>
				<td rowspan="2" style="width: 10vh;padding: 1vh 0 0 2vh;">
					<image src="../../static/19.jpg" mode="" class="user_img"></image>
				</td>
				<td style="font-family: 微软雅黑;">
					姓名：{{i.username}}
				</td>
			</tr>
			<tr>
				<td style="color: gray;">用户编号：123456</td>
			</tr>
			<tr>
				<td colspan="2" class="message">{{i.content}}</td>
			</tr>
			<tr>
				<td colspan="2" class="chose_section">
					<image src="../../static/like.png" mode="" class="small_icon"></image>
					<image src="../../static/letter.png" mode="" class="small_icon"></image>
					<image src="../../static/delete.png" mode="" class="small_icon"></image>
					<image src="../../static/comment.png" mode="" class="small_icon"></image>
				</td>
				
			</tr>
		</table>
		<!-- <div>
			<div class="flex_row">
				<navigator url="" class="small_bar">
					<div class="flex_column">
						<img src="/static/login.gif" alt="" class="img_icon">
						<font>我的</font>
					</div>
				</navigator>
				<navigator url="" class="small_bar">
					<div class="flex_column">
						<img src="/static/login.gif" alt="" class="img_icon">
						<font>我的</font>
					</div>
				</navigator>
				<navigator url="" class="small_bar">
					<div class="flex_column">
						<img src="/static/login.gif" alt="" class="img_icon">
						<font>我的</font>
					</div>
				</navigator>
				<navigator url="" class="small_bar">
					<div class="flex_column">
						<img src="/static/login.gif" alt="" class="img_icon">
						<font>我的</font>
					</div>
				</navigator>
			</div>
		</div> -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				shudong_list: []    // 树洞的列表，数据需要从后端请求来
			}
		},
		// 生命周期函数
		// 当页面一旦显示出来,就自动执行
		onShow() {
			// 获取所有的树洞帖子
			uni.request({
				url:'http://localhost:7777/shudong_get_all.php',
				success: (res) => {
					// console.log(res);
					this.shudong_list = res.data
					console.log(this.shudong_list);
				}
			})
		},
		methods: {
			// 点赞
			like(id){
				console.log(id);
				// const username = uni.getStorageSync('username')
				// console.log(username);
				// uni.showToast({
				// 	title:'点赞成功'
				// })
			}
		}
	}
</script>

<style>
	view{
		background-image: linear-gradient(to bottom right,#f2eff9,#bde7fc);
		background-size: cover;
		background-position: center;
	}
	/* 弹性盒子横着排 */
	.flex_row{
		display: flex; /* 排列方式：弹性盒子 */
		flex-direction: row;/*排列方向：横向*/
		justify-content: center;/*主轴居中*/
		align-items: center;/*副轴居中*/
	}
	/* 弹性盒子竖着排 */
	.flex_column{
		display: flex; /* 排列方式：弹性盒子 */
		flex-direction: column;/*排列方向：纵向*/
		justify-content: center;/*主轴居中*/
		align-items: center;/*副轴居中*/
	}
	.small_bar{
		height: 5vh;
		width: 15vh;
	}
	.img_icon{
		width: 10vh;
		height: 10vh;
		border-radius: 50%;
	}
	table{
		width: 90%;
		margin: 10px auto;
		background-color: rgba(245,245,245,0.80);
		border-radius: 12px;
	}
	.user_img{
		width: 50px;
		height: 50px;
		border-radius: 15px;
	}
	.message{
		height: auto;
		font-family: ;
		font-size: 15px;
		padding: 1vh;
	}
	.small_icon{
		width: 3vh;
		height: 3vh;
		padding-right: 2vh;
	}
	.chose_section{
		text-align: right;
	}
</style>
