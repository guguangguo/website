<template>
	<view>
			<h4 class="top_title">个人中心</h4>
		<div>
			<table>
				<tr>
					<td rowspan="2" style="width: 10vh;padding-left: 7vh;">
						<image src="../../static/19.jpg" mode="" class="user_img"></image>
					</td>
					<td style="font-family: 微软雅黑;">
						姓名：{{username}}
						<navigator v-if="username=='未登录'" url="/pages/login/login">
							<button class="no_login">登录</button>
						</navigator>
					</td>
					<td>
						<font style="color: gray;">扫码</font>
						<image src="../../static/right_arrow.png" mode="" class="link_ui"></image>
					</td>
				</tr>
				<tr>
					<td style="color: gray;">用户编号：123456</td>
				</tr>
			</table>
			<div class="coco" style="margin: 2vh 0 2vh 0;" v-if="username!='未登录'">
				<image src="../../static/home.png" mode="" class="more_ui"></image>
				<font class="font_cy">个人设置</font>
				<image src="../../static/right_arrow.png" mode="" class="more_ui float_right"></image>
			</div>
			<div class="coco" v-if="username!='未登录'">
				<image src="../../static/home.png" mode="" class="more_ui"></image>
				<font class="font_cy">我的订单</font>
				<image src="../../static/right_arrow.png" mode="" class="more_ui float_right"></image>
			</div>
			<navigator url="/pages/password/password" v-if="username!='未登录'">
			<div class="coco" v-if="username!='未登录'">
				<image src="../../static/home.png" mode="" class="more_ui"></image>
				<font class="font_cy">修改密码</font>
				<image src="../../static/right_arrow.png" mode="" class="more_ui float_right"></image>
			</div>
			</navigator>
			<div class="coco" v-if="username!='未登录'">
				<image src="../../static/home.png" mode="" class="more_ui"></image>
				<font class="font_cy">意见反馈</font>
				<image src="../../static/right_arrow.png" mode="" class="more_ui float_right"></image>
			</div>
			<div class="coco" style="margin: 2vh 0 2vh 0;" @click="exit()" v-if="username!='未登录'">
				<image src="../../static/home.png" mode="" class="more_ui"></image>
				<font class="font_cy">退出登录</font>
				<image src="../../static/right_arrow.png" mode="" class="more_ui float_right"></image>
			</div>
		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				username:'未登录'
			}
		},
		// 定义网页的相关方法
		methods: {
			// 退出登录
			exit(){
				// 清除缓存中的用户名
				uni.removeStorageSync('username')
				// 更新页面上的数据为未登录
				this.username = '未登录'
				// 弹框提醒用户
				uni.showToast({
					title:'退出成功'
				})
			}
		},
		// 生命周期函数（当页面显示出来的时候自动调用）
		 onShow(){
			// 如果缓存里有用户名,再去替换,否则不要替换
			if(uni.getStorageSync('username')){ //''为False，否则都是True
				// 读取缓存中存放的用户名，并且更新到页面
				const username = uni.getStorageSync('username')
				this.username = username
			}
		 }
	}
</script>

<style>
	.top_title{
		width: 100%;
		height: 5vh;
		background-color: deepskyblue;
		text-align:center;
		padding-top: 10px;
		color: aliceblue;
	}
	table{
		width: 90%;
		margin: 0 auto;
		background-color: rgba(245,245,245,0.80);
		border-radius: 12px;
		margin-top: 10px;
	}
	.user_img{
		width: 50px;
		height: 50px;
		border-radius: 15px;
	}
	.font_cy{
		font-size: 15px;
		vertical-align: top;
	}
	.link_ui{
		height: 15px;
		width: 15px;
	}
	.more_ui{
		width: 20px;
		height: 20px;
		margin-left: 15px;
	}
	.float_right{
		float: right;
		margin-right: 10px;
	}
	.coco{
		margin-top: 10px;
	}
	div .coco:active{
		transform: scale(0.9);
	}
	.no_login{
		width: 100px;
		font-weight:bold;
		background-color: lightpink;
		font-size: medium;
	}
</style>